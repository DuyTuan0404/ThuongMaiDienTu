// // server.js
// const express = require('express');
// const { Sequelize } = require('sequelize');
const { User, Key, Product } = require('./src/models');
const { Op } = require('@sequelize/core');
// const app = express();
// const port = 3000;


// app.get('/', (req, res) => {
//   res.send('Hello World!');
// });

// app.listen(port, async() => {
//   console.log(`Server is running on port ${port}`);
//   // await User.create({ username: "admin2", password: "Doe123" });
//   // const dbUsers = await User.findAll();
//   // console.log(dbUsers);

// });

const app = require("./src/app");

const PORT = process.env.PORT || 3056;

const server = app.listen(PORT, async () => {
    console.log(`Server listening on port ${PORT}`);

});

process.on('SIGINT', () => {
    server.close(() => {
        console.log('Exit Server Express');
    })
});
