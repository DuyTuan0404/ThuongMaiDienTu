const util = require("util");
const multer = require("multer");
const maxSize = 10 * 1024 * 1024;
let number = Math.floor(Math.random() * 999999999);

let storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, __dirname + '/images/avatar')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + number + '-' + file.originalname)
  }
})


let uploadFile = multer({
  storage: storage,
  limits: { fileSize: maxSize },
  fileFilter: (req, file, cb) => {

    if (file.mimetype == "image/png" || file.mimetype == "image/jpeg" || file.mimetype == "image/gif ") {
      cb(null, true);
    } else {
      cb(null, false);
      const err = new Error('Chỉ cho phép định dạng .png .jpeg .gif!');
      err.code = 'ExtensionError';
      return cb(err);
    }
  },
}).single('file')

let uploadFileMiddleware = util.promisify(uploadFile);
module.exports = uploadFileMiddleware;