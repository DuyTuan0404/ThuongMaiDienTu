'use strict';

const dev = {
    app: {
        port: process.env.DEV_APP_PORT || 3056
    },
    db: {
        host: process.env.DEV_DB_HOST || '192.168.10.212',
        port: process.env.DEV_DB_PORT || 3308,
        name: process.env.DEV_DB_NAME || 'db_test_fresher',
        username: process.env.DEV_DB_USERNAME,
        password: process.env.DEV_DB_PASSWORD,
    }
}

const pro = {
    app: {
        port: process.env.PRO_APP_PORT || 3056
    },
    db: {
        host: process.env.PRO_DB_HOST || '192.168.10.212',
        port: process.env.PRO_DB_PORT || 3308,
        name: process.env.PRO_DB_NAME || 'db_test_fresher',
        password: process.env.PRO_DB_PASSWORD
    }
}

const config = { dev, pro };
const env = process.env.NODE_ENV || 'dev';
module.exports = config[env];