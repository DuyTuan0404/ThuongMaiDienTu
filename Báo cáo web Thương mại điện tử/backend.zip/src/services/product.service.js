'use strict';

const { BadRequestError, NotFoundError } = require('../core/error.response');
const { Product } = require('../models');
const { Op } = require("sequelize");
const path = require('path');
const fs = require('fs');
/*
    Chỉ admin mới tạo được đại lý,
    Đại lý tạo ra nhân viên, khách hàng
    Nhân viên tạo ra khách hàng
*/
const product1 = 'http://localhost:3056/middleware/images/product/1.png'
const product2 = 'http://localhost:3056/middleware/images/product/2.png'
const product3 = 'http://localhost:3056/middleware/images/product/3.png'
const product4 = 'http://localhost:3056/middleware/images/product/4.png'
const product5 = 'http://localhost:3056/middleware/images/product/5.png'
const product6 = 'http://localhost:3056/middleware/images/product/6.png'
const product7 = 'http://localhost:3056/middleware/images/product/7.png'
const product8 = 'http://localhost:3056/middleware/images/product/8.png'
const product9 = 'http://localhost:3056/middleware/images/product/9.png'
const product10 = 'http://localhost:3056/middleware/images/product/10.png'
const product11 = 'http://localhost:3056/middleware/images/product/11.png'
const product12 = 'http://localhost:3056/middleware/images/product/12.png'
const product13 = 'http://localhost:3056/middleware/images/product/13.png'
const product14 = 'http://localhost:3056/middleware/images/product/14.png'
const product15 = 'http://localhost:3056/middleware/images/product/15.png'
const product16 = 'http://localhost:3056/middleware/images/product/16.png'
const product17 = 'http://localhost:3056/middleware/images/product/17.png'
const product18 = 'http://localhost:3056/middleware/images/product/18.png'
const product19 = 'http://localhost:3056/middleware/images/product/19.png'
const product20 = 'http://localhost:3056/middleware/images/product/20.png'
const product21 = 'http://localhost:3056/middleware/images/product/21.png'
const product22 = 'http://localhost:3056/middleware/images/product/22.png'
const product23 = 'http://localhost:3056/middleware/images/product/23.png'
const product24 = 'http://localhost:3056/middleware/images/product/24.png'
const product25 = 'http://localhost:3056/middleware/images/product/25.png'
const product27 = 'http://localhost:3056/middleware/images/product/27.png'
const product26 = 'http://localhost:3056/middleware/images/product/26.png'

class ProductService {

  // tạo mới đại lý by super admin
  async findProduct(
    { keyword, sortBy, page = 1, perPage = 9, priceStart, priceEnd }
  ) {
    // Lấy đường dẫn cha


    let filter = {


    }

    // if (keyword) {
    //     filter = {
    //         ...filter,
    //         [Op.or]: [
    //             { name: { [Op.substring]: keyword } },
    //             { price: { [Op.substring]: keyword*1 } }
    //         ]
    //     }
    // }

    // if (sortBy) {
    //     filter = {
    //         ...filter,
    //         type: sortBy
    //     }
    // }
    if (priceStart || priceEnd) {
      if (priceStart == 'all' && priceEnd == 'all') {
        filter = {
          ...filter,

        }
      } else if (priceStart == 0 && priceEnd == 10) {
        filter = {
          ...filter,
          price: { [Op.gt]: 500 }
        }
      } else if (priceStart == 500 && priceEnd == 0) {
        filter = {
          ...filter,
          price: { [Op.lt]: 10 }
        }
      } else {
        filter = {
          ...filter,
          price: { [Op.between]: [parseInt(priceStart), parseInt(priceEnd)] }
        }
      }

    }


    const product = await Product.findAll(
      {
        where: filter,
        // offset: page*perPage, limit: perPage
        // offset: ,
        // limit: perPage
      }
    )
    return product;
  }

  async createProduct(req) {
    const { slug, brand, hasFreeShipping, price, name, rating, detail } = req.body

    return await Product.create({ slug, brand, hasFreeShipping, price, name, image: `/middleware/images/avatar/${req.file.filename}`, rating, detail });
  }

  async updateProduct(req) {
    const { id, slug, brand, hasFreeShipping, price, name, rating, detail, type } = req.body

    console.log(req.body);
    let originalPath =''
    if (req.file) {

      const parentDirectory = path.dirname(__dirname);
      const getOneProducts = await Product.findOne({
        where: {
          id: id
        }
      });
      originalPath = getOneProducts.dataValues.image.toString();

      // Xóa phần "http://localhost:3056"



      const newPath = originalPath.replace('http://localhost:3056', '');

      const newPath2 = newPath.replace(/\//g, '\\');
      fs.unlinkSync(parentDirectory + newPath2);
    }
    console.log(type);
    return await Product.update({ slug, brand, hasFreeShipping, price, name, image: req.file ? `/middleware/images/avatar/${req.file.filename}` : originalPath, rating, detail }, {
      where: {
        id: id
      }
    });
  }


  async deleteProduct({ productId }) {
    const parentDirectory = path.dirname(__dirname);


    const getOneProducts = await Product.findOne({
      where: {
        id: productId
      }
    });
    const originalPath = getOneProducts.dataValues.image.toString();

    // Xóa phần "http://localhost:3056"



    const newPath = originalPath.replace('http://localhost:3056', '');

    const newPath2 = newPath.replace(/\//g, '\\');
    fs.unlinkSync(parentDirectory + newPath2);


    return await Product.destroy({
      where: {
        id: productId
      }
    });

  }



}

module.exports = new ProductService();