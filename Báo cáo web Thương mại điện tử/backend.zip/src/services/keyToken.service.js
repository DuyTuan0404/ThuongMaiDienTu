"use strict";

const { BadRequestError } = require("../core/error.response");
const { Key } = require("../models");


class KeyTokenService {

    static findByUserId = async (userId) => {
        // return await Key.findOne({
        //     user: Types.ObjectId(userId)
        // });
        return await Key.findOne({ where: { user: userId } });
    }

    static updateKeyToken = async ({
        userId,
        publicKey,
        privateKey,
        refreshToken,
        refreshTokenUsed,
        upsert = true
    }) => {
        const update = {
            publicKey,
            privateKey,
            refreshTokenUsed,
            refreshToken,
        }


        const data = await Key.findOne({ where: { user: userId } });
        if (!data)  throw new BadRequestError('Lỗi cập nhật token') 

        const tokens = await data.update(update);
        if (!tokens) throw new BadRequestError('Lỗi cập nhật token')  
        return tokens ? tokens.dataValues.publicKey : null;

    };

    static createKeyToken = async ({
        userId,
        publicKey,
        privateKey,
        refreshToken = '',
        refreshTokensUsed='',

    }) => {
        const create = {
            user: parseInt(userId),
            publicKey,
            privateKey,
            refreshToken,
            refreshTokensUsed,
           
        }
    
        const tokens = await Key.create(create);
        return tokens ? tokens.dataValues.publicKey : null;

    };

    static removeKeyById = async (id) => {
        return await Key.destroy({
            where: {
                id: id
            }
        });;
    }

    static deleteKeyById = async (userId) => {
        return await Key.destroy({
            where: {
                user: userId
            }
        });

    }
}

module.exports = KeyTokenService;
