'use strict';

const { BadRequestError, NotFoundError } = require('../core/error.response');
const { User } = require('../models');
/*
    Chỉ admin mới tạo được đại lý,
    Đại lý tạo ra nhân viên, khách hàng
    Nhân viên tạo ra khách hàng
*/

class UserService {

    // tạo mới đại lý by super admin
    async findOneUser({ email }) {
        if (!email) throw new NotFoundError('Email hoặc Mật khẩu không được để trống!');
        const checkEmail = await User.findOne({ 
            where: { email: email }, 
            attributes: { exclude: ['password'] }
        })
        return checkEmail;
    }



}

module.exports = new UserService();