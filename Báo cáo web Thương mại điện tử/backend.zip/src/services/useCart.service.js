'use strict';

const { UserCart} = require('../models');
const crypto = require('crypto');
const { Op } = require('sequelize');
const findAllUserCart = async ({userId}) => {
 
    const userCart = await UserCart.findAll({where: { userId: userId}})
    return userCart;
}
const insertOrUpdateUserCart= async ({userId, data}) => {

    const userCartAll = await UserCart.findAll({where: { 
        // productId: {
        //     [Op.in]: data.map(item =>(item.productId)),
        //   },
          userId: userId

    }})
//     data.userCart = userCartAll.map(item => ({id: item.dataValues.id, productId: item.dataValues.productId, qty: item.dataValues.qty} ))
// console.log( data.userCart);

    const uniqueObjectsB = data.filter(objB => {
        return !userCartAll.some(objA => objA.dataValues.productId === objB.productId && objA.dataValues.userId === objB.userId);
      });
    const userCart = await UserCart.bulkCreate(uniqueObjectsB, { fields: ['userId', 'productId', 'qty'] });
    
    return userCart;
}

const insertUserCart= async ({userId, productId, qty}) => {

    const userCart = await UserCart.create({
        userId : userId,
        productId,
        qty
    })

    
    return userCart;
}

module.exports = {
    findAllUserCart,
    insertOrUpdateUserCart,
    insertUserCart
}