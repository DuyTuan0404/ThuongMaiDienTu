'use strict';

const { Apikeys, Key} = require('../models');
const crypto = require('crypto');

const findById = async (key) => {
  
    const objKey = await Apikeys.findOne({where: { key: key}})
    
    return objKey;
}

module.exports = {
    findById
}