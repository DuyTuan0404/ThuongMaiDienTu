'use strict';

const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { BadRequestError, AuthFailureError, ForbiddenError } = require('../core/error.response');
const { User, Key } = require('../models');
const KeyTokenService = require("./keyToken.service");
const { createTokenPair } = require('../auth/authUtils');
const { getInfoData } = require('../utils');


const { SuccessResponse } = require('../core/success.response');
const { findByEmail } = require('./user.service');

const Email = require('./../utils/email');
const db = require('../models');

class AccessService {

    /*
        check this token used?
    */
    static handlerRefreshToken = async ({ keyStore, user, refreshToken }) => {
        const { userId, email } = user;

        if (keyStore.refreshTokensUsed.includes(refreshToken)) {
            await KeyTokenService.deleteKeyById(userId);
            throw new ForbiddenError('Đã xảy ra sự cố!! Vui lòng đăng nhập lại');
        }

        if (keyStore.refreshToken !== refreshToken) throw new AuthFailureError('Người dùng này chưa đăng ký');

        const foundUser = await findByEmail({ where: { email: email } });
        if (!foundUser) throw new AuthFailureError('Người dùng này chưa đăng ký');

        // create 1 cặp mới
        const tokens = await createTokenPair(
            {
                userId, email
            },
            keyStore.publicKey,
            keyStore.privateKey
        );

        // update token
        await keyStore.update({
            $set: {
                refreshToken: tokens.refreshToken,
            },
            $addToSet: {
                refreshTokensUsed: refreshToken, //đã được sử dụng để lấy token mới rồi
            },
        });

        return {
            user,
            tokens,
        };
    }

    static logout = async (keyStore) => {
        const delKey = await KeyTokenService.removeKeyById(keyStore._id);
        return delKey;
    }

    /* 
        1 - check email in dbs
        2 - match password
        3 - create AT vs RT and save
        4 - generate tokens
        5 - get data return login
    */
    static signIn = async ({ email, password, refreshToken = null }) => {
        // 1.
        if (!email) throw new BadRequestError('Email hoặc Mật khẩu không được để trống!');
        const dataUser =await User.findOne({ where: { email: email } })
        if (!dataUser.dataValues) throw new BadRequestError('Người dùng này không tồn tại');
        const foundUser = dataUser.dataValues
        const match = await bcrypt.compare(password, foundUser.password);
        if (!match) throw new AuthFailureError('Mật khẩu không chính xác');
        
        if (foundUser.status === 'inactive') throw new BadRequestError('Tài khoản của bạn đã bị khóa! Vui lòng liên hệ Admin để biết thêm chi tiết!');

        // 3.
        // created privateKey, publicKey
        const privateKey = crypto.randomBytes(64).toString('hex');
        const publicKey = crypto.randomBytes(64).toString('hex');

        // 4. generate tokens
        const { id: userId } = foundUser;
        const tokens = await createTokenPair(
            { userId, email },
            publicKey, privateKey);

        await KeyTokenService.updateKeyToken({
            refreshToken: tokens.refreshToken,
            privateKey,
            publicKey,
            userId
        });
        return {
            user: getInfoData({
                fileds: ['id', 'email', 'avatar', 'role', 'username'],
                object: foundUser
            }),
            tokens
        };
    }

    static signUp = async (req) => {

        
        const {username, email, password, file } = req.body
  
        // step 1: check email tồn tại hay chưa;
        // lean(): giúp query nhanh hơn, giảm tải size của object khi trả về, lean trả về 1 object javascript thuần túy
        if (!email) throw new NotFoundError('Email hoặc Mật khẩu không được để trống!');
        const checkEmail =await User.findOne({ where: { email: email } })

        if (checkEmail) throw new BadRequestError('Email đã tồn tại!');

        const passwordHash = await bcrypt.hash(password, 10);
        const newUser = await User.create({
            email,
            password: passwordHash,
            avatar: req.file ?`/middleware/images/avatar/${req.file.filename}` : '/middleware/images/product/noImage.png',
            username
        });

        if (newUser) {
            // created privateKey, publicKey
            const privateKey = crypto.randomBytes(64).toString('hex');
            const publicKey = crypto.randomBytes(64).toString('hex');

            const { id: userId, email } = newUser.dataValues;
            const tokens2 = await createTokenPair(
                { userId, email },
                publicKey, privateKey);

            const keyStore = await KeyTokenService.createKeyToken({
                userId: newUser.dataValues.id,
                refreshToken: tokens2.refreshToken,
                privateKey,
                publicKey,
            });

  

            if (!keyStore) {
                // throw new BadRequestError('Error: Shop already registered!');
                return {
                    code: "xxx",
                    message: "publicKeyString error",
                };
            }

            // created token pair
            const tokens = await createTokenPair(
                {
                    userId: newUser.dataValues.id, email, avatar: req.file ?`/middleware/images/avatar/${req.file.filename}` : '/middleware/images/product/noImage.png', username
                },
                publicKey,
                privateKey
            );
            console.log(`Created token success:: `, tokens);

            return {
                code: 201,
                data: {
                    user: getInfoData({
                        fileds: ['id', 'email','avatar', 'username'],
                        object: newUser.dataValues
                    }),
                    tokens
                }
            };
        }
        return {
            code: 200,
            data: null
        }

        return await db.Key.create({ 
            user: 2, 
            refreshToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NDU4Njg2MTBkZTliNWUzNzZjMjAyNzMiLCJlbWFpbCI6InR1YW4wNDA0QGdtYWlsLmNvbSIsImlhdCI6MTY4NTkzNzk3MCwiZXhwIjoxNjg2NTQyNzcwfQ.VUGFXZ5B3MjT0DafhFinA1zVkvU2Aa-3Q8Tdqed8bbk",
            publicKey: "d0f372d25f17a305f4de748637904bc0546668cb470e1c8ff038c6a199e2dfe1d608d0b9ac6f89c02e38ff3756c51e31835b8922330e968d8b194e3385693fac",
            privateKey: "d0f372d25f17a305f4de748637904bc0546668cb470e1c8ff038c6a199e2dfe1d608d0b9ac6f89c02e38ff3756c51e31835b8922330e968d8b194e3385693fac"
            ,refreshTokensUsed: ""
        });
    }

    static updateMyPassword = async ({passwordCurrent, user_id, password, passwordConfirm, email})=>{
        // 1) Get user from collection
        const user = await userModel.findById(user_id).select('+password');

        if (!user) throw new BadRequestError('Người dùng này không tồn tại');
        const match = await bcrypt.compare(passwordCurrent, user.password);

        if (!match) throw new AuthFailureError('Mật khẩu không chính xác');

          // 3) If so, update password
        user.password = password;
        user.passwordConfirm = passwordConfirm;
        await user.save();
        const privateKey = crypto.randomBytes(64).toString('hex');
        const publicKey = crypto.randomBytes(64).toString('hex');

        // 4. generate tokens
        const { _id: userId } = user;
        const tokens = await createTokenPair(
            { userId, email },
            publicKey, privateKey);

        await KeyTokenService.updateKeyToken({
            refreshToken: tokens.refreshToken,
            privateKey,
            publicKey,
            userId
        });

        return {
            user: getInfoData({
                fileds: ['_id', 'name', 'email'],
                object: user
            }),
            tokens
        };
    }

    static forgotPassword = async({email, protocol, host})=>{
        // 1) Get user based on POSTed email
        const user = await userModel.findOne({ email });
        if (!user) throw new BadRequestError('Không có người dùng địa chỉ email.')

        const resetToken = user.createPasswordResetToken();
        await user.save({ validateBeforeSave: false });

        try {
            const resetURL = `${protocol}://${host}/v1/api/auth//resetPassword/${resetToken}`;
            await new Email(user, resetURL).sendPasswordReset();
            return null;
          } catch (err) {
            console.log(err);
            user.passwordResetToken = undefined;
            user.passwordResetExpires = undefined;
            await user.save({ validateBeforeSave: false });
        
            throw new BadRequestError('Có một lỗi gửi email.Thử lại sau!')
          }
    
    }

    static resetPassword = async ({token, password, passwordConfirm}) => {
        // 1) Get user based on the token
        const hashedToken = crypto
          .createHash('sha256')
          .update(token)
          .digest('hex');
      
        const user = await userModel.findOne({
          passwordResetToken: hashedToken,
          passwordResetExpires: { $gt: Date.now() }
        });
      
        // 2) If token has not expired, and there is user, set the new password
        if (!user) throw new BadRequestError('Mã thông báo không hợp lệ hoặc đã hết hạn')
        user.password = password;
        user.passwordConfirm = passwordConfirm;
        user.passwordResetToken = undefined;
        user.passwordResetExpires = undefined;
        await user.save();
      
        const privateKey = crypto.randomBytes(64).toString('hex');
        const publicKey = crypto.randomBytes(64).toString('hex');

        // 4. generate tokens
        const { _id: userId } = user;
        const tokens = await createTokenPair(
            { userId, email: user.email },
            publicKey, privateKey);

        await KeyTokenService.updateKeyToken({
            refreshToken: tokens.refreshToken,
            privateKey,
            publicKey,
            userId
        });

        return {
            user: getInfoData({
                fileds: ['_id', 'name', 'email'],
                object: user
            }),
            tokens
        };
    }
}

module.exports = AccessService;