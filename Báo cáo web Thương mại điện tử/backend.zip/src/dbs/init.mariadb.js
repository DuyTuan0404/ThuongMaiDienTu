// 'use strict';
// const mariadb = require('mariadb');
// const { Sequelize } = require('sequelize');
// const { db: { host, name, port, username, password } } = require('../config/config.mongodb');
// const db = require('../models');
// const usernameEncode = encodeURIComponent(username);
// const passwordEncode = encodeURIComponent(password);
// const nameEncode = encodeURIComponent(name);

// const sequelize = new Sequelize(nameEncode, usernameEncode, passwordEncode, {
//     host: host,
//     dialect: "mariadb",                        /* one of 'mysql' | 'postgres' | 'sqlite' | 'mariadb' | 'mssql' | 'db2' | 'snowflake' | 'oracle' */
//     port: port
// });


// class Database {
//     constructor() {
//         this.connect();
//     }

//     // connect
//     connect(type = 'mariadb') {

//         try {
//            db.authenticate();
//            console.log('Kết nối thành công Mariadb');
//           } catch (error) {
//             console.error('Unable to connect to the database:', error);
//           }
        
//         // // nếu môi trường dev thì in ra log
//         // if (1 === 1) {
//         //     mariadb.set('debug', true);
//         //     mariadb.set('debug', { color: true });
//         // // }
//         // mariadb.connect(connectString, {
//         //     maxPoolSize: 50 //max số lượng kết nối tới cơ sở dữ liệu nếu có 50 request thì người 51 phải đợi khi có 1 request của 50 request nhả ra
//         // }).then(_ => {
//             // countConnect();
//         //     console.log('Kết nối thành công Mariadb');
//         // }).catch(err => console.log('Error Connect! ', err));
//     }

//     static getInstance() {
//         if (!Database.instance) {
//             Database.instance = new Database();
//         }

//         return Database.instance;
//     }
// }

// const instanceMongoDb = Database.getInstance();
// module.exports = instanceMongoDb;