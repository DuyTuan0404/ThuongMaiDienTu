'use strict';

const express = require('express');

const { asyncHandler } = require('../../helpers/asyncHandler');
const accessController = require('../../controllers/access.controllers');
const uploadFileMiddleware = require('../../middleware/upload');

const router = express.Router();

router.post('/auth/signin',asyncHandler(accessController.signIn));

router.post('/auth/signup', uploadFileMiddleware, asyncHandler(accessController.signUp));

module.exports = router;