'use strict';

const express = require('express');
const { asyncHandler } = require('../../helpers/asyncHandler');
const { authentication } = require('../../auth/authUtils');
const productController = require('../../controllers/product.controller');
const uploadFileMiddleware = require('../../middleware/upload');

const router = express.Router();

router.use(authentication);

router.get('/all', asyncHandler(productController.findProduct));

router.post('/create',uploadFileMiddleware,  asyncHandler(productController.createProduct));
router.patch('/delete/:productId',  asyncHandler(productController.deleteProduct));
router.post('/update',uploadFileMiddleware,  asyncHandler(productController.updateProduct));
module.exports = router;