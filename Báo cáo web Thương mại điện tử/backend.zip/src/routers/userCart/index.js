'use strict';

const express = require('express');
const { asyncHandler,asyncHandlerFile } = require('../../helpers/asyncHandler');
const { authentication } = require('../../auth/authUtils');
const userCartController = require('../../controllers/userCart.controller');


const router = express.Router();

router.use(authentication);

router.get('/', asyncHandler(userCartController.findAllUserCart));
router.post('/add', asyncHandler(userCartController.insertOrUpdateUserCart));
router.post('/create', asyncHandler(userCartController.insertUserCart));


module.exports = router;