'use strict';

const express = require('express');
const { asyncHandler,asyncHandlerFile } = require('../../helpers/asyncHandler');
const { authentication } = require('../../auth/authUtils');
const userController = require('../../controllers/user.controller');

const accessController = require('../../controllers/access.controllers');
const uploadFileMiddleware = require('../../middleware/upload');

const router = express.Router();

router.use(authentication);

router.post('/', asyncHandler(userController.findOneUser));

router.post('/upload',uploadFileMiddleware, asyncHandler(userController.upload));


module.exports = router;