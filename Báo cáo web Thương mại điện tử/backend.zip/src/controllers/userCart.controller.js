'use strict';

const { CREATED, SuccessResponse } = require("../core/success.response");
const useCartService = require("../services/useCart.service");


class UseCartController {

    findAllUserCart = async (req, res, next) => {
        new SuccessResponse({
            message: 'Lấy danh sách sản phẩm thành công',
            data: await useCartService.findAllUserCart({userId:req.user.userId})
        }).send(res);
    }
    insertOrUpdateUserCart = async (req, res, next) => {
        
        new SuccessResponse({
            message: 'Thêm vào giỏ hàng thành công',
            data: await useCartService.insertOrUpdateUserCart({...req.body, userId:req.user.userId})
        }).send(res);
    }
    insertUserCart = async (req, res, next) => {
        
        new SuccessResponse({
            message: 'Thêm vào giỏ hàng thành công',
            data: await useCartService.insertUserCart({...req.body, userId:req.user.userId})
        }).send(res);
    }

}

module.exports = new UseCartController();