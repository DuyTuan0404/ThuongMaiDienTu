'use strict';

const AccessService = require('../services/access.service');
const { CREATED, SuccessResponse } = require('../core/success.response');

class AccessController {

    handlerRefreshToken = async (req, res, next) => {
        new SuccessResponse({
            message: 'Get token success!',
            data: await AccessService.handlerRefreshToken({
                refreshToken: req.refreshToken,
                user: req.user,
                keyStore: req.keyStore
            })
        }).send(res);
    };

    signUp = async (req, res, next) => {
        new CREATED({
            message: 'Đăng ký thành công!',
            data: await AccessService.signUp(req),
            options: {
                limit: 10
            }
        }).send(res);
    }

    signIn = async (req, res, next) => {

        new SuccessResponse({
            message: 'Đăng nhập thành công!',
            data: await AccessService.signIn(req.body)
        }).send(res);
    }

    logout = async (req, res, next) => {
        new SuccessResponse({
            message: 'Đăng xuất thành công!',
            data: await AccessService.logout(req.keyStore)
        }).send(res);
    };

    updateMyPassword = async (req, res, next) => {
        new SuccessResponse({

            message: 'Cập nhật mật khẩu thành công!',
            data: await AccessService.updateMyPassword({
                user_id: req.user.userId,
                email: req.user.email,
                ...req.body
            })
        }).send(res);
    };

    forgotPassword =  async (req, res, next) => {
        new SuccessResponse({
            message: 'Vui lòng xem lại mail và đổi lại mật khẩu!',
            data: await AccessService.forgotPassword({
                ...req.body,
                host: req.get('host'),
                protocol: req.protocol
            })
        }).send(res);
    };

    resetPassword =  async (req, res, next) => {
       
        new SuccessResponse({
            message: 'Lấy lại mật khẩu thành công!',
            data: await AccessService.resetPassword({
                ...req.body,
                token: req.params.token
            })
        }).send(res);
    };

}

module.exports = new AccessController();