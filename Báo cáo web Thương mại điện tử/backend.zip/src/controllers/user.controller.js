'use strict';

const { CREATED, SuccessResponse } = require("../core/success.response");
const userService = require("../services/user.service");

const uploadFile = require("../middleware/upload");
const fs = require("fs");
const baseUrl = "http://localhost:3056/images/avatar"

class UserController {

    findOneUser = async (req, res, next) => {
        new SuccessResponse({
            message: 'Tạo người dùng thành công',
            data: await userService.findOneUser(req.body)
        }).send(res);
    }

    upload = async (req, res) => {
        console.log("file", req.file.filename);
        try {
          // await uploadFile(req, res);
          if (req.file.length <= 0) {
            return res.status(400).send({ message: "Bạn phải chọn ít nhất 1 tệp!" });
          }
      
          return res.status(200).send({
            message: "Tệp đã được tải lên thành công.",
            data: req
          });
        } catch (err) {
          console.log(err);
          if (err.code == "ExtensionError") {
            return res.status(500).send({ message: err.message });
          }
          if (err.code == "LIMIT_FILE_SIZE") {
            return res.status(500).send({
              message: "Kích thước tệp không được lớn hơn 10MB!",
            });
          }
          if (err.code == "LIMIT_UNEXPECTED_FILE") {
            return res.status(500).send({
              message: "Quá nhiều tệp để tải lên!",
            });
          }
      
          res.status(500).send({
            message: `Lỗi khi thử tải lên nhiều tệp: ${err}`,
          });
        }
      };

}

module.exports = new UserController();