'use strict';

const { CREATED, SuccessResponse } = require("../core/success.response");
const productService = require("../services/product.service");


class ProductController {

    findProduct = async (req, res, next) => {
        new SuccessResponse({
            message: 'Lấy danh sách sản phẩm thành công',
            data: await productService.findProduct(req.query)
        }).send(res);
    }

    createProduct= async (req, res, next) => {
        new CREATED({
            message: 'Thêm sản phẩm thành công',
            data: await productService.createProduct(req)
        }).send(res);
    }

    deleteProduct= async (req, res, next) => {
        new CREATED({
            message: 'Thêm sản phẩm thành công',
            data: await productService.deleteProduct({productId: req.params.productId})
        }).send(res);
    }

    updateProduct= async (req, res, next) => {
        new CREATED({
            message: 'Thêm sản phẩm thành công',
            data: await productService.updateProduct(req)
        }).send(res);
    }
}

module.exports = new ProductController();