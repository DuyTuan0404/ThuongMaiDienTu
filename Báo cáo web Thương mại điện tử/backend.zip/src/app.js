require('dotenv').config();
const compression = require('compression');
const express = require('express');
const helmet = require("helmet");
const morgan = require('morgan');
const multer = require('multer');
const app = express();
const cors = require('cors')
// init middleware
const fs = require('fs')
app.use(cors());
app.options('*', cors());
app.use(morgan('development'));
// morgan('combined');
// morgan('common');
// morgan('short');
// morgan('tiny');
app.use(helmet()); // bảo vệ http
app.use(compression()); // tối ưu giảm size request
app.use(express.json({ limit: '10MB' }));
app.use(express.urlencoded({ extended: true }));

app.use("/middleware/images", express.static(__dirname + "/middleware/images"));

global.__basedir = __dirname;

app.use('/', require('./routers'));

// handling error
app.use((req, res, next) => {
    const error = new Error('Not Found');
    error.status = 404;
    next(error);
});

// app.use((error, req, res, next) => {
//     console.log(error.code);
//     const statusCode = error.status || 500;
//     // const value = error.errmsg.match(/(["'])(\\?.)*?\1/)[0];
//     return res.status(statusCode).json({
//         'status': 'error',
//         code: statusCode,
//         stack: error.stack,
//         message: error.message || 'Internal Server Error'
//     });
// });



module.exports = app;