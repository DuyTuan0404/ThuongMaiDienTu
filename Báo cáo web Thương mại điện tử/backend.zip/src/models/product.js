'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Product extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Product.init({
    name: DataTypes.STRING,
    price: DataTypes.INTEGER,
    image: DataTypes.STRING,
    detail: DataTypes.STRING,
    type:  DataTypes.ENUM(['price-desc','featured','price-asc']),
    slug: DataTypes.STRING,
    brand: DataTypes.STRING,
    hasFreeShipping:  DataTypes.ENUM(['Y', 'N']),
    rating: DataTypes.INTEGER,
  }, {
    sequelize,
    modelName: 'Product',
    timestamps: false
  });
  return Product;
};