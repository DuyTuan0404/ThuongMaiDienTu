'use strict';

const JWT = require('jsonwebtoken');

const { asyncHandler } = require('../helpers/asyncHandler');
const { AuthFailureError, NotFoundError } = require('../core/error.response');

// service
const {User, Key} = require('../models');
const db = require('../models');
const { QueryTypes } = require('sequelize');

const HEADER = {
    API_KEY: 'x-api-key',
    CLIENT_ID: 'x-client-id',
    AUTHORIZATION: 'authorization',
    REFRESHTOKEN: 'x-rtoken-id'
}

const createTokenPair = async (payload, publicKey, privateKey) => {
    try {
        // accessToken
        const accessToken = await JWT.sign(payload, publicKey, {
            expiresIn: '2 days'
        });
        const refreshToken = await JWT.sign(payload, privateKey, {
            expiresIn: '7 days'
        });

        JWT.verify(accessToken, publicKey, (err, decode) => {
            if (err) {
                console.log(`Error verify:: `, err);
            } else {
                console.log(`decode verify:: `, decode);
            }
        });
        return { accessToken, refreshToken };
    } catch (error) {
        console.log(error);
    }
}

const verifyJWT = async (token, keySecret) => {
    return await JWT.verify(token, keySecret);
}

const authentication = asyncHandler(async (req, res, next) => {
    /*
        1 - Check userId missing??
        2 - get accessToken
        3 - verify accessToken
        4 - check user in dbs?
        5 - check keyStore with this userId?
        6 - OK all => return next()
    */

    // 1.
    const userId = req.headers[HEADER.CLIENT_ID];
    if (!userId) throw new AuthFailureError('Invalid Request');
    const keyStore2 = await Key.findOne({where: { user: userId}})
    if (!keyStore2) throw new NotFoundError('Không tìm thấy keyStore');
    if (!keyStore2.dataValues) throw new NotFoundError('Không tìm thấy keyStore');
    let keyStore = keyStore2.dataValues
    // 3.
    if (req.headers[HEADER.REFRESHTOKEN] || req.headers[HEADER.REFRESHTOKEN] != undefined) {
        try {
            const refreshToken = req.headers[HEADER.REFRESHTOKEN];
            const decodeUser = JWT.verify(refreshToken, keyStore.privateKey);
            if (userId !== decodeUser.userId) throw new AuthFailureError('Invalid User');
            req.keyStore = keyStore;
            req.user = decodeUser;
            req.refreshToken = refreshToken;
            return next();
        } catch (error) {
            console.log('Lỗi', error);
            throw error
        }
    }

    const accessToken = req.headers[HEADER.AUTHORIZATION];
    if (!accessToken) throw new AuthFailureError('Invalid Request');
    const decodeUser2 = JWT.verify(accessToken, keyStore.publicKey);
    try {
        const decodeUser = JWT.verify(accessToken, keyStore.publicKey);
        console.log(userId, decodeUser.userId);
        if (parseInt(userId) !== decodeUser.userId) throw new AuthFailureError("Invalid User");
        const currentUser = await User.findOne({where: {id: userId}})
        if (!currentUser) throw new AuthFailureError('Invalid User');
        
        req.keyStore = keyStore;
        delete currentUser.dataValues.password
        req.user = {
            ...currentUser.dataValues,
            ...decodeUser
        }; // {userId, email}
        return next();
    } catch (error) {

        console.log('ERROR', error);
        throw error;
    }

});

module.exports = {
    createTokenPair,
    authentication,
    verifyJWT
}