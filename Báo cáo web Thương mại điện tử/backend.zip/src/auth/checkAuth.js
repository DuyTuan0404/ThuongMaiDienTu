'use strict';

const { ForbiddenError } = require('../core/error.response');
const { findById } = require('../services/apiKey.service');

const HEADER = {
    API_KEY: 'x-api-key',
    AUTHORIZATION: 'authorization'
}

const apiKey = async (req, res, next) => {
    try {
        const key = req.headers[HEADER.API_KEY]?.toString();
        if (!key) {
            return next(new ForbiddenError('Forbidden Error'));
        }
        // check objKey
        const objKey = await findById(key);

        if (!objKey) {
            return next(new ForbiddenError('Forbidden Error'));
        }
        req.objKey = objKey;
        return next();
    } catch (error) {

    }
}

const permissions = (permission) => {
    return (req, res, next) => {
        if (!req.objKey.permissions) {
            return res.status(403).json({
                message: 'Permission Dinied'
            });
        }
        console.log('permissions:: ', req.objKey.permissions);
        const validPermissions = req.objKey.permissions.includes(permission);
        if (!validPermissions) {
            return res.status(403).json({
                message: 'permission denied'
            });
        }
        return next();
    }
}

// // phân quyền người dùng
// const restrictTo = (role) => {
//     return (req, res, next) => {
//         // console.log(`Người dùng:: `, req.user.roles.groupRole);
//         const arrRolesGroupCurrent = req.user.role.groupRole;
//         const result = arrRolesGroupCurrent.map(obj => obj.roleGroup_code);
//         if (!result.includes(role)) {
//             throw new ForbiddenError('Bạn không có quyền thực hiện hành động này');
//         }
//         // ; // ['perm_get', 'perm_add']
//         // console.log(role);
//         next();
//     };
// };

module.exports = {
    apiKey,
    permissions,
    // restrictTo
}