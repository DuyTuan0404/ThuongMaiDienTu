'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Products', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: [true, 'Email đã tồn tại']
      },
      price: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      image: {
        type: Sequelize.STRING,
      },
      detail: {
        type: Sequelize.STRING
      },
      slug: {
        type: Sequelize.STRING
      },
      hasFreeShipping {
        type: Sequelize.ENUM,
        defaultValue: 'Y'
      },
      type: {
        type: Sequelize.ENUM,
        defaultValue: 'Y'
      },
      rating: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      // 'slug', 'brand', 'hasFreeShipping', 'price', 'name', 'image', 'rating'
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Products');
  }
};