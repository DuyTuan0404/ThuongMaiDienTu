import mock from '../mock'
/* eslint-disable */
// ** Utils
import { paginateArray, sortCompare, randomDate, getRandomInt } from '../utils'
const api = 'http://localhost:3056/v1/api'

// Images Imports


const nextDay = new Date(new Date().getTime() + 24 * 60 * 60 * 1000)
const nextWeek = new Date(nextDay.getTime() + 7 * 24 * 60 * 60 * 1000)

// GET: Return cart
// ------------------------------------------------
mock.onGet('/apps/ecommerce/userCart').reply(async config => {
  // eslint-disable-next-line object-curly-newline
  const { q = '', sortBy = 'featured', perPage = 9, page = 1, priceStart = 'all', priceEnd = 'all'} = config.params

  const queryLowered = q.toLowerCase()
    const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));

  const getData = await fetch(`${api}/userCart`, {
    headers: {
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    }
  })
  const dataUserCart = await getData.json()

  return [
    200,
    {
      total: dataUserCart.data.length,
      userCart: dataUserCart.data
    }
  ]
})

