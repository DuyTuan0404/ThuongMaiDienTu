import mock from '../mock'
/* eslint-disable */
// ** Utils
import { paginateArray, sortCompare, randomDate, getRandomInt } from '../utils'
const api = 'http://localhost:3056/v1/api'

// Images Imports


const nextDay = new Date(new Date().getTime() + 24 * 60 * 60 * 1000)
const nextWeek = new Date(nextDay.getTime() + 7 * 24 * 60 * 60 * 1000)

const data = {
  products: [
    
  ],
  userWishlist: [

  ],
  userCart: [

  ]
}
/* eslint-enable */

// ------------------------------------------------
// GET: Return products
// ------------------------------------------------
mock.onGet('/apps/ecommerce/products').reply(async config => {
  // eslint-disable-next-line object-curly-newline
  const { q = '', sortBy = 'featured', perPage = 9, page = 1, priceStart = 'all', priceEnd = 'all'} = config.params

  const queryLowered = q.toLowerCase()
  const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));

  const filteredData2 = await fetch(`${api}/product/all?priceStart=${priceStart}&priceEnd=${priceEnd}`, {
    headers: {
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    }
  })

  if (filteredData2.status == 200) {
    const dataProduct = await filteredData2.json()
    data.products = dataProduct.data
    const filteredData = dataProduct.data.filter(product => product.name.toLowerCase().includes(queryLowered))
    let sortDesc = false
    const sortByKey = (() => {
      if (sortBy === 'price-desc') {
        sortDesc = true
        return 'price'
      }
      if (sortBy === 'price-asc') {
        return 'price'
      }
      sortDesc = true
      return 'id'
    })()
  
    const sortedData = filteredData.sort(sortCompare(sortByKey))
    if (sortDesc) sortedData.reverse()
    const paginatedData = JSON.parse(JSON.stringify(paginateArray(sortedData, perPage, page)))
  
    paginatedData.forEach(product => {
      /* eslint-disable no-param-reassign */
      product.isInWishlist = data.userWishlist.findIndex(p => p.productId === product.id) > -1
      product.isInCart = data.userCart.findIndex(p => p.productId === product.id) > -1
      /* eslint-enable */
    })
    return [
      200,
      {
        products: paginatedData,
        total: filteredData.length,
        userWishlist: data.userWishlist,
        userCart: data.userCart
      }
    ]
  }


  

  
})

// ------------------------------------------------
// GET: Return Single Product
// ------------------------------------------------
mock.onGet(/\/apps\/ecommerce\/products\/\d+/).reply(config => { 
  // Get product id from URL
  let productId = config.url.substring(config.url.lastIndexOf('/')+1)
  const product = data.products.filter(item =>item.id == productId)
 
  
  if (product.length > 0) {
    // Add data of wishlist and cart
    product[0].isInWishlist = data.userWishlist.findIndex(p => p.productId === product[0].id) > -1
    product[0].isInCart = data.userCart.findIndex(p => p.productId === product[0].id) > -1

    // * Add Dummy data for details page
    product[0].colorOptions = ['primary', 'success', 'warning', 'danger', 'info']
    let obj =  product[0]
    return [200, { ...obj }]
  }
  return [404]
})

// ------------------------------------------------
// GET: Return Wishlist Products
// ------------------------------------------------
mock.onGet('/apps/ecommerce/wishlist').reply(() => {
  const products = data.userWishlist.map(wishlistProduct => {
    const product = data.products.find(p => p.id === wishlistProduct.productId)
    product.isInCart = data.userCart.findIndex(p => p.productId === wishlistProduct.productId) > -1
    return product
  })

  return [200, { products }]
})


// GET USER
mock.onGet('/apps/ecommerce/productId').reply(config => {
  const { id } = config
  const product = data.products.find(i => i.id === id)
  return [200, { product }]
})

// ------------------------------------------------
// GET: Return Cart Products
// ------------------------------------------------
mock.onGet('/apps/ecommerce/cart').reply(async() => {

  const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));

  const getData = await fetch(`${api}/userCart`, {
    headers: {
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    }
  })
  const dataUserCart = await getData.json()
  data.userCart= dataUserCart.data

  const products = data.userCart.map(cartProduct => {

    
    
    const product = data.products.find(p => p.id === cartProduct.productId)

    // Other data
    product.isInWishlist = data.userWishlist.findIndex(p => p.productId === cartProduct.productId) > -1
    product.qty = cartProduct.qty
    product.shippingDate = randomDate(nextDay, nextWeek)
    product.offers = getRandomInt(1, 4)
    product.discountPercentage = getRandomInt(3, 20)

    return product
  })

  return [200, { products }]
})

// ------------------------------------------------
// POST: Add Item in user Cart
// ------------------------------------------------
mock.onPost('/apps/ecommerce/cart').reply(async config => {
  // Get product from post data
  const { productId } = JSON.parse(config.data)

  const { length } = data.userCart
  let lastId = 0
  if (length) lastId = data.userCart[length - 1].i



  const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));

  const upCartUser = await fetch(`${api}/userCart/create`, {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    },
    body: JSON.stringify({
      productId,
      qty: 1
    })
  })
  const dataUpUserCart = await upCartUser.json()
  data.userCart.push(dataUpUserCart.data)
  return [201]
})

// ADD PRODUCT

// Hàm để chuyển đổi base64 thành đối tượng File
function base64ToFile(base64String, filename) {
  const arr = base64String.split(',');
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);

  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }

  return new File([u8arr], filename, { type: mime });
}

mock.onPost('/apps/ecommerce/addProducts').reply(async config => {
  const {slug, brand, hasFreeShipping, price, name, rating, image, filename, detail} = JSON.parse(config.data)
  
  // // Get event from post data
  const product = JSON.parse(config.data)
  const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));

  const file = base64ToFile(image, filename);  
  var data2 = new FormData()
  data2.append('file', file)
  data2.append('slug', slug)
  data2.append('brand', brand)
  data2.append('price', price)
  data2.append('name', name)
  data2.append('rating', rating)
  data2.append('hasFreeShipping', hasFreeShipping)
  data2.append('detail', detail)

  const upCartUser = await fetch(`${api}/product/create`, {
    method: 'POST',
    headers: {
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    },
    body: data2
  })
  const dataUpUserCart = await upCartUser.json()
  
  data.userCart.push(dataUpUserCart.data)

  return [201, { ...dataUpUserCart.data }]
})

mock.onPost('/apps/ecommerce/updateProducts').reply(async config => {
  
  const {slug, brand, hasFreeShipping,type, price, name, rating, image, filename, detail, id} = JSON.parse(config.data)
  
  // // Get event from post data
  const product = JSON.parse(config.data)
  const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));

  const file = base64ToFile(image, filename);  
  var data2 = new FormData()

  if (filename) {
    data2.append('file', file)
  }
  data2.append('id', id)
  data2.append('slug', slug)
  data2.append('brand', brand)
  data2.append('type', type)
  data2.append('price', price)
  data2.append('name', name)
  data2.append('rating', rating)
  data2.append('hasFreeShipping', hasFreeShipping)
  data2.append('detail', detail)

  const upCartUser = await fetch(`${api}/product/update`, {
    method: 'POST',
    headers: {
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    },
    body: data2
  })
  const dataUpUserCart = await upCartUser.json()
  
  data.userCart.push(dataUpUserCart.data)

  return [201, { ...dataUpUserCart.data }]
})

// mock.onPost('/apps/ecommerce/addProducts').reply(async config => {
//   // Get product from post data
//   const { name, price, slug, detail, brand, hasFreeShipping, image, type, rating } = JSON.parse(config.data)
//   const user = JSON.parse(localStorage.getItem('userData'));
//   const accessToken = JSON.parse(localStorage.getItem('accessToken'));

//   const upCartUser = await fetch(`${api}/product/create`, {
//     method: 'POST',
//     headers: {
//       'Accept': 'application/json',
//       'Content-Type': 'application/json',
//       'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
//       'x-client-id': user.id,
//       'authorization': accessToken
//     },
//     body: JSON.stringify({
//       data: [{
//         name, price, slug, detail, brand, hasFreeShipping, image, type, rating
//       }]
//     })
//   })
//   const dataUpUserCart = await upCartUser.json()
//   data.userCart.push(dataUpUserCart.data)
//   return [201]
// })

// ------------------------------------------------
// DELETE: Remove Item from user Cart
// ------------------------------------------------
mock.onDelete(/\/apps\/ecommerce\/cart\/\d+/).reply(config => {
  // Get product id from URL
  let productId = config.url.substring(config.url.lastIndexOf('/') + 1)

  // Convert Id to number
  productId = Number(productId)

  const productIndex = data.userCart.findIndex(i => i.productId === productId)
  if (productIndex > -1) data.userCart.splice(productIndex, 1)

  return [200]
})

mock.onDelete(/\/apps\/ecommerce\/product\/\d+/).reply(async config => {
  // Get product id from URL
  let productId = config.url.substring(config.url.lastIndexOf('/') + 1)

  // Convert Id to number
  productId = Number(productId)


  const user = JSON.parse(localStorage.getItem('userData'));
  const accessToken = JSON.parse(localStorage.getItem('accessToken'));
  const upCartUser = await fetch(`${api}/product/delete/${productId}`, {
    method: 'PATCH',
    headers: {
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e',
      'x-client-id': user.id,
      'authorization': accessToken
    }
  })
  const dataUpUserCart = await upCartUser.json()

  // xóa khỏi products án userCart
  data.userCart = data.userCart.filter(item => item.productId !=productId)
  
  data.products =data.products.filter(item=> item.id != productId)

  

  return [200]
})
// ------------------------------------------------
// POST: Add Item in user Wishlist
// ------------------------------------------------
mock.onPost('/apps/ecommerce/wishlist').reply(config => {
  // Get product from post data
  const { productId } = JSON.parse(config.data)

  const { length } = data.userWishlist
  let lastId = 0
  if (length) lastId = data.userWishlist[length - 1].i

  data.userWishlist.push({
    id: lastId + 1,
    productId: Number(productId)
  })

  return [201]
})

// ------------------------------------------------
// DELETE: Remove Item from user Wishlist
// ------------------------------------------------
mock.onDelete(/\/apps\/ecommerce\/wishlist\/\d+/).reply(config => {
  // Get product id from URL
  let productId = config.url.substring(config.url.lastIndexOf('/') + 1)

  // Convert Id to number
  productId = Number(productId)

  const productIndex = data.userWishlist.findIndex(i => i.productId === productId)
  if (productIndex > -1) data.userWishlist.splice(productIndex, 1)

  return [201, { ...dataUpUserCart.data }]
})
