import mock from '../mock'
import jwt from 'jsonwebtoken'

// Avatar Imports
import avatar1 from '@src/assets/images/avatars/1-small.png'
import avatar11 from '@src/assets/images/portrait/small/avatar-s-11.jpg'

const api = 'http://localhost:3056/v1/api'
const data = {
  users: [
    {
      id: 1,
      fullName: 'John Doe',
      username: 'johndoe',
      password: 'admin',
      avatar: avatar11,
      email: 'admin@demo.com',
      role: 'admin',
      ability: [
        {
          action: 'manage',
          subject: 'all'
        }
      ],
      extras: {
        eCommerceCartItemsCount: 5
      }
    },
    {
      id: 2,
      fullName: 'Jane Doe',
      username: 'janedoe',
      password: 'client',
      avatar: avatar1,
      email: 'client@demo.com',
      role: 'client',
      ability: [
        {
          action: 'read',
          subject: 'ACL'
        },
        {
          action: 'read',
          subject: 'Auth'
        }
      ],
      extras: {
        eCommerceCartItemsCount: 5
      }
    }
  ]
}

// ! These two secrets shall be in .env file and not in any other file
const jwtConfig = {
  secret: 'dd5f3089-40c3-403d-af14-d0c228b05cb4',
  refreshTokenSecret: '7c4c1c50-3230-45bf-9eae-c9b2e401c767',
  expireTime: '10m',
  refreshTokenExpireTime: '10m'
}

mock.onPost('/jwt/login').reply(async (request) => {
  const { email, password } = JSON.parse(request.data)

  let error = {
    email: ['Something went wrong']
  }

  const login = await fetch(`${api}/auth/signin`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e'
    },
    body: JSON.stringify({ email: email, password: password })
  })
  if (login.status == 200) {


    const dataLogin = await login.json();

    if (dataLogin) {

      const accessToken = dataLogin.data.tokens.accessToken
      const refreshToken = dataLogin.data.tokens.refreshToken

      let dataMau =
        dataLogin.data.user.username == 'admin' ?
          {
            ability: [
              {
                action: 'manage',
                subject: 'all'
              }
            ],
            extras: {
              eCommerceCartItemsCount: 5
            },
          } : {
            ability: [
              {
                action: 'read',
                subject: 'ACL'
              },
              {
                action: 'read',
                subject: 'Auth'
              }
            ],
            extras: {
              eCommerceCartItemsCount: 5
            }
          }


      let user = {

        fullName: dataLogin.data.user.username,
        role: dataLogin.data.user.role,
        ...dataMau,
        ...dataLogin.data.user
      }

      const response = {
        userData: user,
        accessToken,
        refreshToken
      }
      return [200, response]
    } else {
      error = 'Email or Password is Invalid'
    }
  } else {
    error = 'Email or Password is Invalid'
  }
  return [400, { error }]
})
// Hàm để chuyển đổi base64 thành đối tượng File
function base64ToFile(base64String, filename) {
  const arr = base64String.split(',');
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);

  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }

  return new File([u8arr], filename, { type: mime });
}

mock.onPost('/jwt/register').reply(async (request) => {  
  if (request.data.length > 0) {
    const { email, password, username, avatar, filename } = JSON.parse(request.data)
    
    // Sử dụng hàm
  
  
   
    
    const file = base64ToFile(avatar, filename);  
    var data = new FormData()
    data.append('file', file)
    data.append('email', email)
    data.append('password', password)
    data.append('username', username)
    
    const login = await fetch(`${api}/auth/signup`, {
      method: 'POST',
      headers: {
        'x-api-key': 'c6b5a5c98928327f8e1708eddbf6ca1610f74a8eda936399b0dbae23b86f0cfe4b8874b08a5a482239422f06bab34c3056d6ed8fd6d4e709aef0a69c55a23e9e'
      },
      body: data
    })

    const error = {
      email: 'This email is already in use.' || null,
    }

  

    if (login.status == 201) {
      const resigter = await login.json();
        const userData = {
          email,
          password,
          username,
          fullName: username,
          avatar: avatar,
          role: 'client',
          ability: [
            {
              action: 'read',
              subject: 'ACL'
            },
            {
              action: 'read',
              subject: 'Auth'
            }
          ],
          extras: {
            eCommerceCartItemsCount: 5
          }
        }
     
        const accessToken = resigter.data.data.tokens.accessToken
        const user = Object.assign({}, userData)

        const response = { user, accessToken }
        return [200, response]
    } else {
      return [200, { error }]
    }



    // if (!error.username && !error.email) {
    //   const userData = {
    //     email,
    //     password,
    //     username,
    //     fullName: '',
    //     avatar: null,
    //     role: 'admin',
    //     ability: [
    //       {
    //         action: 'manage',
    //         subject: 'all'
    //       }
    //     ]
    //   }

    //   // Add user id
    //   const length = data.users.length
    //   let lastIndex = 0
    //   if (length) {
    //     lastIndex = data.users[length - 1].id
    //   }
    //   userData.id = lastIndex + 1

    //   data.users.push(userData)

    //   const accessToken = jwt.sign({ id: userData.id }, jwtConfig.secret, { expiresIn: jwtConfig.expireTime })

    //   const user = Object.assign({}, userData)
    //   delete user['password']
    //   const response = { user, accessToken }

    //   return [200, response]
    // } else {
    //   return [200, { error }]
    // }
  }
})

mock.onPost('/jwt/refresh-token').reply(request => {
  const { refreshToken } = JSON.parse(request.data)

  try {
    const { id } = jwt.verify(refreshToken, jwtConfig.refreshTokenSecret)

    const userData = { ...data.users.find(user => user.id === id) }

    const newAccessToken = jwt.sign({ id: userData.id }, jwtConfig.secret, { expiresIn: jwtConfig.expiresIn })
    const newRefreshToken = jwt.sign({ id: userData.id }, jwtConfig.refreshTokenSecret, {
      expiresIn: jwtConfig.refreshTokenExpireTime
    })

    delete userData.password
    const response = {
      userData,
      accessToken: newAccessToken,
      refreshToken: newRefreshToken
    }

    return [200, response]
  } catch (e) {
    const error = 'Invalid refresh token'
    return [401, { error }]
  }
})
