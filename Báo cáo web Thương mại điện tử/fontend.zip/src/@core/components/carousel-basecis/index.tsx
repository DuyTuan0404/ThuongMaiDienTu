import React, { useRef, useState, useEffect  } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import { useDispatch, useSelector } from 'react-redux'

// Import Swiper styles
import "swiper/css";

import './index.css';
const API_BACKEND = 'http://localhost:3056'
// import required modules
import { Navigation, Pagination, Mousewheel, Keyboard, Autoplay } from 'swiper';
import { margin, minWidth } from "@mui/system";

export default function App(props) {
  const {products, getProducts} = props

    // ** Vars
    const dispatch = useDispatch()
    const store = useSelector(state => state.ecommerce)
    
    useEffect(() => {
      dispatch(
        getProducts({
          q: '',
          sortBy: 'featured',
          perPage: 9,
          page: 1
        })
      )
    }, [dispatch])
  return (
    <div style={{width: '100%'}}>
    <Swiper watchSlidesProgress={true} slidesPerView={3} className="mySwiper">
        {
          store.products.map((item, index) => {

            return(
              <SwiperSlide style={{margin: '10px'}} key={item.id}>
                <img src={API_BACKEND+item.image} style={{objectFit: 'none', paddingBottom: 250}} crossOrigin="anonymous"></img>
                <p style={{position: 'fixed', color: 'black', minWidth: 250}}>{item.name}</p>
              </SwiperSlide>
            )
          })
          
        }
      </Swiper>
    </div>
  );
}
