import React, { useRef, useState } from 'react';
// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

import './index.css';

import banner1 from './imageBanner/Banner1.jpg';
import banner2 from './imageBanner/Banner2.jpg';
import banner3 from './imageBanner/Banner3.png';
// import required modules
import { Navigation, Pagination, Mousewheel, Keyboard, Autoplay } from 'swiper';

export default function App() {
  return (
    <div style={{width: '100%'}}>
    <Swiper
        spaceBetween={30}
        centeredSlides={true}
        autoplay={{
        delay: 2500,
        disableOnInteraction: false,
        }}
        pagination={{
        clickable: true,
        }}
        navigation={true}
        modules={[Autoplay, Pagination, Navigation]}
        className="mySwiper"
    >
        <SwiperSlide>
            <img crossOrigin="anonymous" src={banner1} style={{  objectFit: 'cover'}}/>
        </SwiperSlide>
        <SwiperSlide>
            <img crossOrigin="anonymous" src={banner2}/>
        </SwiperSlide>
        <SwiperSlide>
            <img crossOrigin="anonymous" src={banner3} style={{  objectFit: 'cover'}}/>
        </SwiperSlide>
        <SwiperSlide>
            <img crossOrigin="anonymous" src={banner2} style={{  objectFit: 'cover'}}/>
        </SwiperSlide>

      </Swiper>
    </div>
  );
}
