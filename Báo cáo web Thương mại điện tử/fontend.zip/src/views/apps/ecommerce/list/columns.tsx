// ** React Imports
import { Link } from 'react-router-dom'

// ** Custom Components
// import Avatar from '@components/avatar'
import Avatar from '@mui/material/Avatar';
// ** Store & Actions
import { store } from '@store/store'
import { getProductId, deleteProduct } from '../store'

// ** Icons Imports
import { Slack, User, Settings, Database, Edit2, MoreVertical, FileText, Trash2, Archive } from 'react-feather'

// ** Reactstrap Imports
import { Badge, UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap'
import { useDispatch } from 'react-redux'
import { useEffect } from 'react';
const API_BACKEND = 'http://localhost:3056'
// ** Renders Client Columns
const renderClient = row => {
  if (row.image.length) {
    let chuoi = row.image;
    let a = chuoi.startsWith("http://");
    if (a) {
      return <img className='d-block rounded me-1' crossOrigin="anonymous" src={row.image} alt={row.name} width='62' />
    }else{
      return <img className='d-block rounded me-1' crossOrigin="anonymous" src={`${API_BACKEND}${row.image}`} alt={row.name} width='62' />
    }
    
    
  } else {
    return (
      <Avatar sx={{ bgcolor: deepOrange[500] }}>{row.name}</Avatar>
    )
  }
}

// ** Renders Role Columns
const renderRole = row => {
  const roleObj = {
    subscriber: {
      class: 'text-primary',
      icon: User
    },
    maintainer: {
      class: 'text-success',
      icon: Database
    },
    editor: {
      class: 'text-info',
      icon: Edit2
    },
    author: {
      class: 'text-warning',
      icon: Settings
    },
    admin: {
      class: 'text-danger',
      icon: Slack
    }
  }

  const Icon = roleObj[row.role] ? roleObj[row.role].icon : Edit2

  return (
    <span className='text-truncate text-capitalize align-middle'>
      <Icon size={18} className={`${roleObj[row.role] ? roleObj[row.role].class : ''} me-50`} />
      {row.role}
    </span>
  )
}



const statusObj = {
  pending: 'light-warning',
  active: 'light-success',
  inactive: 'light-secondary'
}

export const columns = [
  {
    name: 'Actions',
    width: '110px',
    cell: row => (
      <div className='column-action'>
        <UncontrolledDropdown>
          <DropdownToggle tag='div' className='btn btn-sm'>
            <MoreVertical size={14} className='cursor-pointer' />
          </DropdownToggle>
          <DropdownMenu>
            <DropdownItem
              tag={Link}
              className='w-100'
              to={`/apps/ecommerce/product-detail/${row.id}`}
              onClick={() => store.dispatch(getProductId(row.id))}
            >
              <FileText size={14} className='me-50' />
              <span className='align-middle'>Details</span>
            </DropdownItem>
            <DropdownItem 
            className='w-100'
            onClick={e=> e.preventDefault()}>
              <Archive size={14} className='me-50' />
              <span className='align-middle'>Edit</span>
            </DropdownItem>
            <DropdownItem
            to={`/apps/ecommerce/product/${row.id}`}
              className='w-100'
              onClick={()=>store.dispatch(deleteProduct(row.id))}
            >
              <Trash2 size={14} className='me-50' />
              <span className='align-middle'>Delete</span>
            </DropdownItem>
          </DropdownMenu>
        </UncontrolledDropdown>
      </div>
    )
  },
  {
    name: 'Image',
    sortable: true,
    width: '120px',
    sortField: 'image',
    selector: row => row.image,
    cell: row => (
      <div className='d-flex justify-content-left align-items-center'>
        {renderClient(row)}
       
      </div>
    )
  },
  {
    name: 'Name Product',
    sortable: true,
    minWidth: '300px',
    sortField: 'name',
    selector: row => row.name,
    cell: row => <span className='text-capitalize fw-bolder'>{row.name ? row.name: ''}</span>
  },
  {
    name: 'Price',
    sortable: true,
    width: '110px',
    sortField: 'price',
    selector: row => row.price,
    cell: row => <span className='text-capitalize' style={{textAlign: 'end'}}>{row.price} $</span>
  },
  {
    name: 'Type',
    sortable: true,
    minWidth: '110px',
    sortField: 'type',
    selector: row => row.price,
    cell: row => <span className='text-capitalize'>{row.type ? row.type: ''}</span>
  },
  {
    name: 'Slug',
    sortable: true,
    minWidth: '220px',
    sortField: 'slug',
    selector: row => row.slug,
    cell: row => <span className='text-capitalize'>{row.slug? row.slug: ''}</span>
  },
  {
    name: 'Brand',
    minWidth: '120px',
    sortable: true,
    sortField: 'brand',
    selector: row => row.brand,
    cell: row => <span className='text-capitalize justify-content-left'>{row.brand ? row.brand: ''}</span>
  },
  {
    name: 'Has Free Shipping',
    minWidth: '100px',
    sortable: true,
    type: Boolean,
    sortField: 'hasFreeShipping',
    textAlign: 'center',
    selector: row => row.hasFreeShipping,
    cell: row => <span className='text-capitalize justify-content-center align-items-center'>{row.hasFreeShipping}</span>
  },
  
]
