// ** React Import
import { useState, useEffect } from 'react'

// ** Custom Components
import Sidebar from '@components/sidebar'

// ** Utils
import { selectThemeColors } from '@utils'

// ** Third Party Components
import Select from 'react-select'
import classnames from 'classnames'
import { useForm, Controller } from 'react-hook-form'
import slugify from 'react-slugify';
// ** Reactstrap Imports
import { Button, Label, FormText, Form, Input } from 'reactstrap'

// ** Store & Actions
import { updateProducts } from '../store'
import { useDispatch } from 'react-redux'

const defaultValues = {
  name: '',
  type: { label: 'Featured', value: 'featured' },
  price: 0,
  image: '',
  detail: '',
  slug: slugify(name),
  brand: '',
  hasFreeShipping: 'Y',
  rating: 0
}


const countryOptions = [
  { label: 'Price Desc', value: 'price-desc' },
  { label: 'Featured', value: 'featured' },
  { label: 'Price Asc', value: 'price-asc' },
]

const checkIsValid = data => {
  return Object.values(data).every(field => ( field ? field !== null : field.length > 0))
}

const SidebarEditProduct = ({ open, toggleSidebar, rowEdit }) => {
  // ** States
  const [data, setData] = useState(null)
  const [plan, setPlan] = useState('basic')
  const [role, setRole] = useState('subscriber')
  const [imageUrl, setImageUrl] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);

  const [base64Image, setBase64Image] = useState('');
  // ** Store Vars
  
  const dispatch = useDispatch()
  
  const handleFileChange = (e) => {
    
    const file = e.target.files[0];
    if (file) {

      const reader = new FileReader();
      reader.onload = (val) => {

       
        setValue('image', reader.result)
        setImageUrl(reader.result);
      };
      reader.readAsDataURL(file);
      setSelectedFile(file);
      
    }

   
  };
  // ** Vars
  const {
    control,
    setValue,
    setError,
    handleSubmit,
    formState: { errors }
  } = useForm({ defaultValues })


  useEffect(()=>{
    if (rowEdit) {
      setValue('name', rowEdit.name)
      setValue('price', rowEdit.price)
      
      setValue('detail', rowEdit.detail)
      setValue('brand', rowEdit.brand)
      setValue('detail', rowEdit.detail)
      setValue('rating', rowEdit.rating)
      setValue('slug', rowEdit.slug)
      
      setValue('type', countryOptions.find(option => option.value === rowEdit.type))
      setImageUrl(rowEdit.image)


      fetch(rowEdit.image)
      .then((response) => response.blob())
      .then((blob) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64data = reader.result;
          setValue('image', base64data)
        };
        reader.readAsDataURL(blob);
      })
      .catch((error) => {
        console.error('Error loading image:', error);
      });
    }
    
    
    
  },[rowEdit])

  // ** Function to handle form submit
  const onSubmit = data => {
 
    

    setData(data)

    data.type = data.type.value || '';
    data.filename = ''
    if (selectedFile) {
      
      data.filename =  selectedFile.name
    }
    
   
    let checkData = {name: data.name, price: data.price, detail: data.detail, slug: data.slug}
    
    if (checkIsValid(checkData)) {
      toggleSidebar()
     
      dispatch(updateProducts({...data, id: rowEdit.id}))
    } else {
    

      for (const key in checkData) {
     
        
        if (checkData[key] !== null && checkData[key] <= 0) {
            
            setError('price', {
              type: 'custom',
              message: 'Price is greater than 0'
            })
       
          
        }
        if (checkData[key] === null) {
         
          
          setError('country', {
            type: 'manual',
            message: 'cannot be left blank'
          })
        }
        if (checkData[key] !== null && checkData[key].toString().length === 0) {
          
          setError(key, {
            type: 'manual',
            message: 'cannot be left blank'
          })
        }

        
      }
    }
  }

  const handleSidebarClosed = () => {
    for (const key in defaultValues) {
      setValue(key, '')
    }
    setRole('subscriber')
    setPlan('basic')
  }

  return (
    <Sidebar
      size='lg'
      open={open}
      title='Add Products'
      headerClassName='mb-1'
      contentClassName='pt-0'
      toggleSidebar={toggleSidebar}
      onClosed={handleSidebarClosed}
    >
      <Form onSubmit={handleSubmit(onSubmit)}>
      <div className='mb-1'>
          <div style={{textAlign: 'center'}}> 
              {
                  imageUrl && <img alt='Upload' crossOrigin="anonymous" src={imageUrl} width={100} height={100}></img>
              }
          </div>
          <br></br>
          <Label className='form-label' for='register-password'>
            Upload image
          </Label>
          
          
          <Input
          type="file"
          accept=".png, .jpg, .jpeg"
          onChange={handleFileChange}
        />
            <Controller
            id='image'
            name='image'
            control={control}
            render={({ field }) => (
              <Input autoFocus style={{display: 'none'}} invalid={errors.image && true} {...field} />
            )}
          />
                  
            {/* <div className="mt-3">
              {imageUrl && <img src={imageUrl} alt="Uploaded" style={{ width: '100%' }} />}
            </div> */}
        </div>
        <div className='mb-1'>
          <Label className='form-label' for='name'>
            Name <span className='text-danger'>*</span>
          </Label>
          <Controller
            name='name'
            control={control}
            render={({ field }) => (
              <Input id='name' placeholder='Máy điện tử' invalid={errors.name && true} {...field} />
            )}
          />
        </div>
        <div className='mb-1'>
          <Label className='form-label' for='price'>
          Price <span className='text-danger'>*</span>
          </Label>
          <Controller
            name='price'
            control={control}
            render={({ field }) => (
              <Input id='price' type='number' placeholder='99' invalid={errors.price && true} {...field} />
            )}
          />
        </div>
        <div className='mb-1'>
          <Label className='form-label' for='detail'>
            Detail <span className='text-danger'>*</span>
          </Label>
          <Controller
            name='detail'
            control={control}
            render={({ field }) => (
              <Input
                type='detail'
                id='detail'
                placeholder='Sản phẩm không có'
                invalid={errors.detail && true}
                {...field}
              />
            )}
          />
          <FormText color='muted'>You can use letters, numbers & periods</FormText>
        </div>
        <div className='mb-1'>
          <Label className='form-label' for='rating'>
          Rating <span className='text-danger'></span>
          </Label>
          <Controller
            name='rating'
            control={control}
            render={({ field }) => (
              <Input id='rating' type='number' placeholder='99' invalid={errors.rating && true} {...field} />
            )}
          />
        </div>
        

        <div className='mb-1'>
          <Label className='form-label' for='brand'>
          Brand <span className='text-danger'></span>
          </Label>
          <Controller
            name='brand'
            control={control}
            render={({ field }) => (
              <Input id='brand' placeholder='(397) 294-5153' {...field} />
            )}
          />
        </div>
        <div className='mb-1'>
          <Label className='form-label' for='slug'>
            Slug <span className='text-danger'></span>
          </Label>
          <Controller
            name='slug'
            control={control}
            render={({ field }) => (
              <Input id='slug' placeholder='-s-s-s-' invalid={errors.slug && true} {...field} />
            )}
          />
        </div>
        <div className='mb-1'>
          <Label className='form-label' for='type'>
            Type <span className='text-danger'></span>
          </Label>
          <Controller
            name='type'
            control={control}
            render={({ field }) => (
              // <Input id='country' placeholder='Australia' invalid={errors.country && true} {...field} />
              <Select
                isClearable={false}
                classNamePrefix='select'
                options={countryOptions}
                theme={selectThemeColors}
                defaultValues={{ label: 'Featured', value: 'featured' }}
                // className={classnames('react-select', { 'is-invalid': data !== null && data.country === null })}
                {...field}
              />
            )}
          />
        </div>

        <div className='mb-1' value={plan} onChange={e => setPlan(e.target.value)}>
          <Label className='form-label' for='select-plan'>
            Select Has Free Shipping
          </Label>
          <Input type='select' id='hasFreeShipping' name='select-plan'>
            <option value='Y'>Y</option>
            <option value='N'>N</option>
      
          </Input>
        </div>
        <Button type='submit' className='me-1' color='primary'>
          Submit
        </Button>
        <Button type='reset' color='secondary' outline onClick={toggleSidebar}>
          Cancel
        </Button>
      </Form>
    </Sidebar>
  )
}

export default SidebarEditProduct
