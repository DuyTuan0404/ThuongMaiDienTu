// ** Custom Hooks
import { useRTL } from '@hooks/useRTL'
import {useState} from 'react'
// ** Third Party Components
import wNumb from 'wnumb'
import classnames from 'classnames'
import { Star } from 'react-feather'
import Nouislider from 'nouislider-react'

// ** Reactstrap Imports
import { Card, CardBody, Row, Col, Input, Button, Label } from 'reactstrap'

// ** Styles
import '@styles/react/libs/noui-slider/noui-slider.scss'

const Sidebar = props => {
  // ** Props
  // sidebarOpen={sidebarOpen}  store={store}
  //     dispatch={dispatch} getProducts={getProducts}
  const { sidebarOpen, store,  dispatch, getProducts} = props
  const [selectedRange, setSelectedRange] = useState('all');

  const handleRangeChange = (event) => {
   
    if (event.target.id) {
      let price = event.target.id;
      if (price == 'all') {
        dispatch(getProducts({...store.params, priceStart : 'all', priceEnd: 'all'}))
      }else if(price == '<10'){
        dispatch(getProducts({...store.params, priceStart : 0, priceEnd: 10}))
      }else if(price == '10-100'){
        dispatch(getProducts({...store.params, priceStart : 10, priceEnd: 100}))
      }else if(price == '100-500'){
        dispatch(getProducts({...store.params, priceStart : 100, priceEnd: 500}))
      }else{
        dispatch(getProducts({...store.params, priceStart : 500, priceEnd: 0}))
      }
      
    }
  };
  return (
    <div className='sidebar-detached sidebar-left'>
      <div className='sidebar'>
        <div
          className={classnames('sidebar-shop', {
            show: sidebarOpen
          })}
        >
          <Row>
            <Col sm='12'>
              <h6 className='filter-heading d-none d-lg-block'>Filters</h6>
            </Col>
          </Row>
          <Card>
            <CardBody>
              <div className='multi-range-price'>
                <h6 className='filter-title mt-0'>Multi Range</h6>
                
                <ul className='list-unstyled price-range'>
                  <li>
                    <div className='form-check'>
                      <Input type='radio' id='all'    defaultChecked={selectedRange === 'all'}
                      onChange={handleRangeChange} name='price-range-radio' />
                      <Label className='form-check-label' for='all'>
                        All
                      </Label>
                    </div>
                  </li>
                  <li>
                    <div className='form-check'>
                      <Input type='radio' id='<=10' onChange={handleRangeChange}  name='price-range-radio' />
                      <Label className='form-check-label' for='10-dollars-below'>{`<=$10`}</Label>
                    </div>
                  </li>
                  <li>
                    <div className='form-check'>
                      <Input type='radio' id='10-100' onChange={handleRangeChange} name='price-range-radio' />
                      <Label className='form-check-label' onChange={handleRangeChange} for='10-100-dollars'>
                        $10-$100
                      </Label>
                    </div>
                  </li>
                  <li>
                    <div className='form-check'>
                      <Input type='radio' id='100-500' onChange={handleRangeChange} name='price-range-radio' />
                      <Label className='form-check-label' for='100-500-dollars'>
                        $100-$500
                      </Label>
                    </div>
                  </li>
                  <li>
                    <div className='form-check'>
                      <Input type='radio' id='>500' onChange={handleRangeChange} name='price-range-radio' />
                      <Label className='form-check-label' for='500-dollars-above'>{`>=$500`}</Label>
                    </div>
                  </li>
                </ul>
              </div>
              {/* <div className='price-slider'>
                <h6 className='filter-title'>Price Range</h6>
                <div className='price-slider'>
                  <Nouislider
                    className='range-slider mt-2'
                    direction={isRtl ? 'rtl' : 'ltr'}
                    start={[1500, 3500]}
                    connect={true}
                    tooltips={[true, true]}
                    format={wNumb({
                      decimals: 0
                    })}
                    range={{
                      min: 51,
                      max: 5000
                    }}
                  />
                </div>
              </div>
              <div id='product-categories'>
                <h6 className='filter-title'>Categories</h6>
                <ul className='list-unstyled categories-list'>
                  {categories.map(category => {
                    return (
                      <li key={category.id}>
                        <div className='form-check'>
                          <Input
                            type='radio'
                            id={category.id}
                            name='category-radio'
                            defaultChecked={category.defaultChecked}
                          />
                          <Label className='form-check-label' for={category.id}>
                            {category.title}
                          </Label>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              </div>
              <div className='brands'>
                <h6 className='filter-title'>Brands</h6>
                <ul className='list-unstyled brand-list'>
                  {brands.map(brand => {
                    return (
                      <li key={brand.title}>
                        <div className='form-check'>
                          <Input type='checkbox' id={brand.title} defaultChecked={brand.checked} />
                          <Label className='form-check-label' for={brand.title}>
                            {brand.title}
                          </Label>
                        </div>
                        <span>{brand.total}</span>
                      </li>
                    )
                  })}
                </ul>
              </div>
              <div id='ratings'>
                <h6 className='filter-title'>Ratings</h6>
                {ratings.map(item => {
                  return (
                    <div key={item.total} className='ratings-list'>
                      <a href='/' onClick={e => e.preventDefault()}>
                        <ul className='unstyled-list list-inline'>
                          {new Array(5).fill().map((listItem, index) => {
                            return (
                              <li key={index} className='ratings-list-item me-25'>
                                <Star
                                  className={classnames({
                                    'filled-star': index + 1 <= item.ratings,
                                    'unfilled-star': index + 1 > item.ratings
                                  })}
                                />
                              </li>
                            )
                          })}
                          <li>& up</li>
                        </ul>
                      </a>
                      <div className='stars-received'>{item.total}</div>
                    </div>
                  )
                })}
              </div>
              <div id='clear-filters'>
                <Button color='primary' block>
                  Clear All Filters
                </Button>
              </div> */}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Sidebar
