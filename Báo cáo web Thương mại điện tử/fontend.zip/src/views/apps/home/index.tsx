import React from 'react';

import Carousel from '@src/@core/components/carousel/index.jsx'
import CarouselBasecis from '@src/@core/components/carousel-basecis/index.jsx'

import RelatedProducts from '../ecommerce/detail/RelatedProducts'
import { Card, CardBody } from 'reactstrap'

import classnames from 'classnames'
import { Star } from 'react-feather'
import SwiperCore, { Navigation } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react'
import { CardText } from 'reactstrap'
import Grid from '@mui/material/Grid';
import { useDispatch, useSelector } from 'react-redux'
import { getProducts } from '../ecommerce/store'

const HomeApp = () => {
  SwiperCore.use([Navigation])
  const dispatch = useDispatch()
  const store = useSelector(state => state.ecommerce)

  const slides = [
    {
      name: 'Apple Watch Series 6',
      brand: 'Apple',
      ratings: 4,
      price: 399.98,
      img: 'http://localhost:3056/middleware/images/product/1.png'
    },
    {
      name: 'Apple MacBook Pro - Silver',
      brand: 'Apple',
      ratings: 2,
      price: 2449.49,
      img: 'http://localhost:3056/middleware/images/product/1.png'
    },
    {
      name: 'Apple HomePod (Space Grey)',
      brand: 'Apple',
      ratings: 3,
      price: 229.29,
      img: 'http://localhost:3056/middleware/images/product/1.png'
    },
    {
      name: 'Magic Mouse 2 - Black',
      brand: 'Apple',
      ratings: 3,
      price: 90.98,
      img: 'http://localhost:3056/middleware/images/product/1.png'
    },
    {
      name: 'iPhone 12 Pro',
      brand: 'Apple',
      ratings: 4,
      price: 1559.99,
      img: 'http://localhost:3056/middleware/images/product/1.png'
    }
  ]

  const params = {
    className: 'swiper-responsive-breakpoints swiper-container px-4 py-2',
    slidesPerView: 5,
    spaceBetween: 55,
    navigation: true,
    breakpoints: {
      1600: {
        slidesPerView: 4,
        spaceBetween: 55
      },
      1300: {
        slidesPerView: 3,
        spaceBetween: 55
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 55
      },
      320: {
        slidesPerView: 1,
        spaceBetween: 55
      }
    }
  }
  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <Carousel/>
      </Grid>

      <Grid item xs={12}>
        <CarouselBasecis products={store.products} getProducts={getProducts}/>
      </Grid>
    </Grid>
    
  );
};

export default HomeApp;

